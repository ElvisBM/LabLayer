#!/bin/bash
set -euo pipefail
app=/var/www/lablayer/app
release=$(pwd)
backup="$HOME/deploy-backups/$(basename "$release")"
cd "$app"
sha256sum --check "$release/baseline"
mkdir -p "$backup"
files=(server/assistant.ts shared/assistant/workflow.ts src/features/assistant/AssistantChat.tsx src/features/assistant/AssistantStatusUpdate.tsx dist/index.html)
tar czf "$backup/prior.tgz" "${files[@]}"
rollback() {
  tar xzf "$backup/prior.tgz"
  pm2 restart lablayer-app >/dev/null
}
trap rollback ERR
for f in "${files[@]:0:4}"; do install -m 644 "$release/$f" "$f.next"; mv "$f.next" "$f"; done
for f in "$release"/dist/assets/*; do install -m 644 "$f" "dist/assets/$(basename "$f").next"; mv "dist/assets/$(basename "$f").next" "dist/assets/$(basename "$f")"; done
pm2 restart lablayer-app >/dev/null
ready=false
for i in {1..60}; do
  if curl --max-time 3 -fsS http://localhost:3000/api/health 2>/dev/null | grep -q '"ok"'; then ready=true; break; fi
  sleep 1
done
$ready
for f in "${files[@]:4}"; do install -m 644 "$release/$f" "$f.next"; mv "$f.next" "$f"; done
sha256sum dist/index.html
trap - ERR
